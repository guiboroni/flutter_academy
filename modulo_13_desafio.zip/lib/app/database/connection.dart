import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:synchronized/synchronized.dart';
import 'package:todo_list/app/database/migrations/migration_v1.dart';
import 'package:todo_list/app/database/migrations/migration_v2.dart';

class Connection {
  static const VERSION = 1;
  static const DATABASE_NAME = "TODO_LIST";
  static Connection _instance; // instancia unica da classe, singleton
  Database _db;
  final _lock =
      Lock(); // Usado para controle de requisições de conexão ao banco,
  // evita duas requisições de conexão no mesmo espaço de tempo

  // Construtor criado manualmente que retorna uma instancia unica da classe
  factory Connection() {
    if (_instance == null) {
      _instance = Connection._();
    }

    return _instance;
  }

  // Construtor nomeado inacessível externamente
  Connection._();

  // Retorna a conexão com o banco de dados
  Future<Database> get instance async => await _openConnection();

  // Abre uma conexão com o banco de dados
  Future<Database> _openConnection() async {
    // Se não existe conexão aberta, inicia o sincronismo para garantir apenas uma requisição de abertura
    // de conexão
    if (_db == null) {
      await _lock.synchronized(() async {
        if (_db == null) {
          var databasePath = await getDatabasesPath();
          var pathDatabase = join(databasePath, DATABASE_NAME);
          print(pathDatabase);
          _db = await openDatabase(
            pathDatabase,
            version: VERSION,
            onConfigure: _onConfigure,
            onCreate: _onCreate,
            onUpgrade: _onUpgrade,
          );
        }
      });
    }

    return _db;
  }

  // Fecha a conexão com o banco de dados
  void closeConnection() {
    _db?.close(); // se a conexão não é nula, fecha ela
    _db = null;
  }

  // Configura as foreign key do banco
  Future<FutureOr<void>> _onConfigure(Database db) async {
    await db.execute('PRAGMA foreign_keys = ON');
  }

  // Cria as tabelas de dados. Chamado na primeira vez do app
  FutureOr<void> _onCreate(Database db, int version) {
    var batch = db.batch();
    createV1(batch);
    batch.commit();
  }

  // Chamado sempre que o banco for atualizado a versão VERSION
  FutureOr<void> _onUpgrade(Database db, int oldVersion, int newVersion) {
    var batch = db.batch();

    if (oldVersion < 2) {
      upgradeV2(batch);
    }

    if (oldVersion < 3) {
      //upgradeV3(batch);
    }

    batch.commit();
  }
}
