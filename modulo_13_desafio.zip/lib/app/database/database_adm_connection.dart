import 'package:flutter/widgets.dart';

import 'connection.dart';

class DatabaseAdmConnection with WidgetsBindingObserver {
// Controle o estado do app no celular do usuário (quando é aberto, fechado, minimizado,
  // pausado e por ai vai)
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    var connection = Connection();
    switch (state) {
      case AppLifecycleState.resumed:
        break;
      case AppLifecycleState.inactive:
        connection.closeConnection();
        break;
      case AppLifecycleState.paused:
        connection.closeConnection();
        break;
      case AppLifecycleState.detached:
        connection.closeConnection();
        break;
    }
    super.didChangeAppLifecycleState(state);
  }
}
