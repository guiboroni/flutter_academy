import 'package:flushbar/flushbar.dart';
import 'package:flutter/material.dart';

void buildFlushbar(BuildContext context, String text, bool newTask) {
  Flushbar(
    message: text,
    duration: Duration(seconds: 2),
  ).show(context).then((value) => newTask ? Navigator.of(context).pop() : null);
}
