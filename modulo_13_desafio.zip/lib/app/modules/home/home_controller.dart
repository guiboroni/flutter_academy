import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:todo_list/app/models/todo_model.dart';
import 'package:todo_list/app/repositories/todos_repositorys.dart';
import 'package:collection/collection.dart';

class HomeController extends ChangeNotifier {
  final TodosRepository todosRepository;
  int selectedTab = 1;
  DateTime daySelected;
  DateTime startFilter;
  DateTime endFilter;
  var dateFormat = DateFormat('dd/MM/yyyy');
  Map<String, List<TodoModel>> listTodos;

  // Contrutor
  HomeController({@required this.todosRepository}) {
    findAllForWeek();
  }

  //! Muda o menu selecionado na home do sistema
  Future<void> changeSelectedTab(BuildContext context, int index) async {
    selectedTab = index;

    switch (index) {
      case 0:
        filterFinalized();
        break;
      case 1:
        findAllForWeek();
        break;
      case 2:
        var day = await showDatePicker(
          context: context,
          initialDate: daySelected,
          firstDate: DateTime.now().subtract(Duration(days: 360 * 3)),
          lastDate: DateTime.now().add(Duration(days: 360 * 10)),
        );

        if (day != null) {
          daySelected = day;
          findTodosBySelectedDay();
        }
        break;
      default:
    }

    notifyListeners();
  }

  // ! Retorna as tarefas da semana
  Future<void> findAllForWeek() async {
    daySelected = DateTime.now();
    startFilter = DateTime.now();

    // Se não é o primeiro dia da semana, subtrai os dias até chegar no primeiro
    if (startFilter.weekday != DateTime.monday) {
      startFilter =
          startFilter.subtract(Duration(days: (startFilter.weekday - 1)));
    }

    // Calcula o última dia da semana
    endFilter = startFilter.add(Duration(days: 6));

    // Filtra os dados e monta seguindo a regra:
    // Se não tiver nenhuma tarefa exibe apenas a data de Hoje
    // Se tiver tarefas retorna os dados agrupados pela data_hora
    var todos = await todosRepository.findByPeriod(startFilter, endFilter);
    if (todos.isEmpty) {
      listTodos = {dateFormat.format(DateTime.now()): []};
    } else {
      listTodos = groupBy(todos,
          (TodoModel todoModel) => dateFormat.format(todoModel.dataHora));
    }

    notifyListeners();
  }

  // ! Marca/Desmarca a tarefa
  void checkOrUncheck(TodoModel todoModel) {
    todoModel.finalizado = !todoModel.finalizado;
    notifyListeners();

    // Atualiza no banco
    todosRepository.checkOrUnckeckTodo(todoModel);
  }

  // ! Retorna as tarefas finalizadas
  void filterFinalized() {
    // Percorre cada map de data e lista de todo e depois filtra os todo pelos finalizados
    listTodos = listTodos.map((key, value) {
      var todosFinalized = value.where((t) => t.finalizado).toList();

      // retorna uma nova lista mapeada com os finalizados
      return MapEntry(key, todosFinalized);
    });

    notifyListeners();
  }

  // ! Retorna as tarefas da data selecionada no calendario
  Future<void> findTodosBySelectedDay() async {
    var todos = await todosRepository.findByPeriod(daySelected, daySelected);

    if (todos.isEmpty) {
      listTodos = {dateFormat.format(daySelected): []};
    } else {
      listTodos = groupBy(todos,
          (TodoModel todoModel) => dateFormat.format(todoModel.dataHora));
    }

    notifyListeners();
  }

  // ! Atualiza os dados da tela. Usado após salvar uma tarefa
  void update() {
    // tab semanal
    if (selectedTab == 1) {
      findAllForWeek();
    }
    // tab selecionar data
    else if (selectedTab == 2) {
      findTodosBySelectedDay();
    }
  }

  // ! Remove uma tarefa da tela
  Future<void> removeTask(int idTask) async {
    await todosRepository.removeTask(idTask);
  }
}
