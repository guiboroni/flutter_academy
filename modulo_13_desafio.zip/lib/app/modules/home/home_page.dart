import 'package:ff_navigation_bar/ff_navigation_bar.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:todo_list/app/models/todo_model.dart';
import 'package:todo_list/app/modules/home/home_controller.dart';
import 'package:todo_list/app/modules/new_task/new_task_page.dart';
import 'package:todo_list/app/shared/build_flush_bar.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<HomeController>(
      builder: (BuildContext context, HomeController controller, _) {
        return Scaffold(
          appBar: AppBar(
            title: Text(
              'Atividades',
              style: TextStyle(color: Theme.of(context).primaryColor),
            ),
            backgroundColor: Colors.white,
          ),
          bottomNavigationBar: FFNavigationBar(
            selectedIndex: controller.selectedTab,
            onSelectTab: (index) =>
                controller.changeSelectedTab(context, index),
            items: [
              FFNavigationBarItem(
                iconData: Icons.check_circle,
                label: 'Finalizados',
              ),
              FFNavigationBarItem(
                iconData: Icons.view_week,
                label: 'Semanal',
              ),
              FFNavigationBarItem(
                iconData: Icons.calendar_today,
                label: 'Selecionar Data',
              ),
            ],
            theme: FFNavigationBarTheme(
              itemWidth: 60,
              barHeight: 70,
              barBackgroundColor: Theme.of(context).primaryColor,
              unselectedItemIconColor: Colors.white,
              unselectedItemLabelColor: Colors.white,
              selectedItemBorderColor: Colors.white,
              selectedItemIconColor: Colors.white,
              selectedItemBackgroundColor: Theme.of(context).primaryColor,
              selectedItemLabelColor: Colors.black,
            ),
          ),
          body: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: ListView.builder(
              itemCount: controller.listTodos?.keys?.length ?? 0,
              itemBuilder: (_, index) {
                var dateFormat = DateFormat('dd/MM/yyyy');

                // Pega todas as tarefas
                var listTodos = controller.listTodos;

                // Pega a chave da tarefa que é a data
                var dayKey = listTodos.keys.elementAt(index);
                var day = dayKey;

                // Pega as tarefas da chave
                var todos = listTodos[dayKey];

                // Se o dia não tem tarefa finalizadas, não exibe nada nele
                if (todos.isEmpty && controller.selectedTab == 0) {
                  return SizedBox.shrink();
                }

                // Se a data de hoje for igual a data da chave da lista
                var today = DateTime.now();
                if (dayKey == dateFormat.format(today)) {
                  day = 'HOJE';
                  // Se a data de amanhã for igual a data da chave da lista
                } else if (dayKey ==
                    dateFormat.format(today.add(Duration(days: 1)))) {
                  day = 'AMANHÃ';
                }

                return Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Padding(
                      padding:
                          const EdgeInsets.only(left: 20, right: 20, top: 20),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              day,
                              style: TextStyle(
                                  fontSize: 30, fontWeight: FontWeight.bold),
                            ),
                          ),
                          IconButton(
                            icon: Icon(
                              Icons.add_circle,
                              color: Theme.of(context).primaryColor,
                              size: 30,
                            ),
                            onPressed: () async {
                              // Espera o retorna do save e recarrega os dados
                              await Navigator.of(context).pushNamed(
                                  NewTaskPage.routerName,
                                  arguments: dayKey);

                              controller.update();
                            },
                          ),
                        ],
                      ),
                    ),
                    ListView.builder(
                      shrinkWrap:
                          true, // permite uma lista dentro de outra lista
                      physics:
                          NeverScrollableScrollPhysics(), // remove a rolagem da lista
                      itemCount: todos.length,
                      itemBuilder: (_, index) {
                        // Pega a tarefa
                        var todo = todos[index];

                        return Dismissible(
                            key: Key(index.toString()),
                            background: Container(
                              color: Theme.of(context).primaryColor,
                              child: Align(
                                alignment: Alignment(-0.9, 0.0),
                                child: Icon(Icons.delete, color: Colors.white),
                              ),
                            ),
                            direction: DismissDirection.startToEnd,
                            onDismissed: (direction) {
                              controller.removeTask(todo.id);
                              buildFlushbar(context,
                                  'Tarefa apagada com sucesso.', false);
                            },
                            child: listTile(context, todo, controller));
                      },
                    ),
                  ],
                );
              },
            ),
          ),
        );
      },
    );
  }

  Widget listTile(
      BuildContext context, TodoModel todo, HomeController controller) {
    return ListTile(
      leading: Checkbox(
        activeColor: Theme.of(context).primaryColor,
        value: todo.finalizado,
        onChanged: (_) => controller.checkOrUncheck(todo),
      ),
      title: Text(
        todo.descricao,
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          decoration: todo.finalizado ? TextDecoration.lineThrough : null,
        ),
      ),
      trailing: Text(
          '${todo.dataHora.hour.toString().padLeft(2, '0')}: ${todo.dataHora.minute.toString().padLeft(2, '0')}',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            decoration: todo.finalizado ? TextDecoration.lineThrough : null,
          )),
    );
  }
}
