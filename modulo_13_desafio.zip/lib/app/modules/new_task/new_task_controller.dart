import 'package:flutter/cupertino.dart';
import 'package:intl/intl.dart';
import 'package:todo_list/app/repositories/todos_repositorys.dart';

class NewTaskController extends ChangeNotifier {
  final TodosRepository todosRepository;

  // Controles para a data selecionada no calendario na tela de listagem
  DateTime daySelected;
  final dateFormat = DateFormat('dd/MM/yyyy');

  // Controles para pegar o campo digitavel
  TextEditingController nomeTaskController = TextEditingController();
  final formKey = GlobalKey<FormState>();

  // Get para retornar da data selecionada
  String get dayFormated => dateFormat.format(daySelected);

  // Controle de criação de nova tarefa
  bool saved = false;
  bool loading = false;
  String error = '';

  // Contrutor
  // Recebe a data e guarda ela formatada
  NewTaskController({@required this.todosRepository, String day}) {
    daySelected = dateFormat.parse(day);
  }

  // Salva uma nova tarefa
  Future<void> saveTask() async {
    try {
      if (formKey.currentState.validate()) {
        loading = true;
        saved = false;
        await todosRepository.saveTodo(daySelected, nomeTaskController.text);
        saved = true;
        loading = false;
      }
    } catch (e) {
      print(e);
      error = 'Erro ao salvar tarefa';
    }

    notifyListeners();
  }
}
