import 'dart:convert';

import 'package:cuidapet_curso/app/models/endereco_model.dart';
import 'package:cuidapet_curso/app/models/usuario_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_modular/flutter_modular.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SharedPrefsRepository {
  static const _ACCESS_TOKEN = '/_ACCESS_TOKEN/';
  static const _DEVICE_ID = '/_DEVICE_ID/';
  static const _DADOS_USUARIO = '/_DADOS_USUARIO';
  static const _ENDERECO_SELECIONADO = '/_ENDERECO_SELECIONADO';

  // Usado para gravar dados no celular do usuário
  static SharedPreferences prefs;

  // Instancia unica da classe
  static SharedPrefsRepository _instanceRepository;

  // Contrutor privado
  SharedPrefsRepository._();

  // Retorna uma instancia dos preferences
  static Future<SharedPrefsRepository> get instance async {
    prefs ??= await SharedPreferences.getInstance();
    _instanceRepository ??= SharedPrefsRepository._();
    return _instanceRepository;
  }

  // Registra o token no celular
  Future<void> registerAccessToken(String token) async {
    await prefs.setString(_ACCESS_TOKEN, token);
  }

  // Retorna o token registrado
  String get accessToken => prefs.get(_ACCESS_TOKEN);

  // Registra o id do celular
  Future<void> registerDeviceID(String deviceId) async {
    await prefs.setString(_DEVICE_ID, deviceId);
  }

  // Retorna o id do celular
  String get deviceID => prefs.get(_DEVICE_ID);

  // Registra os dados do usuário logado
  Future<void> registerDadosUsuario(UsuarioModel usuario) async {
    await prefs.setString(_DADOS_USUARIO, jsonEncode(usuario));
  }

  // Retorna os dados do usuário
  UsuarioModel get dadosUsuario {
    if (prefs.containsKey(_DADOS_USUARIO)) {
      Map<String, dynamic> usuarioMap =
          jsonDecode(prefs.getString(_DADOS_USUARIO));
      return UsuarioModel.fromJson(usuarioMap);
    }

    return null;
  }

  // Desloga o usuário
  Future<void> logout() async {
    await prefs.clear();
    await Modular.to.pushNamedAndRemoveUntil('/', ModalRoute.withName('/'));
  }

  // Registra na memoria do app o endereço selecionado
  Future<void> registrarEnderecoSelecionado(EnderecoModel model) async {
    await prefs.setString(_ENDERECO_SELECIONADO, model.toJson());
  }

  Future<EnderecoModel> get enderecoSelecionado async {
    var enderecoJson = prefs.getString(_ENDERECO_SELECIONADO);
    if (enderecoJson != null) {
      return EnderecoModel.fromJson(enderecoJson);
    }
    return null;
  }
}
