import 'package:cuidapet_curso/app/core/database/connection.dart';
import 'package:cuidapet_curso/app/models/endereco_model.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:google_maps_webservice/places.dart';

class EnderecoRepository {
  // Retorna todos os endereços e converte em uma model de enderecos
  Future<List<EnderecoModel>> buscarEnderecos() async {
    final conn = await Connection().instance;
    var result = await conn.rawQuery('select * from endereco');
    return result.map((e) => EnderecoModel.fromMap(e)).toList();
  }

  // Salva um novo endereço
  Future<void> salvarEndereco(EnderecoModel enderecoModel) async {
    final conn = await Connection().instance;
    await conn.rawInsert('insert into endereco values(?,?,?,?,?)', [
      null,
      enderecoModel.endereco,
      enderecoModel.latitude,
      enderecoModel.longitude,
      enderecoModel.complemento
    ]);
  }

  // Limpa a tabela de endereços
  Future<void> limparEnderecosCadastrados() async {
    final conn = await Connection().instance;
    await conn.rawDelete('delete * from endereco');
  }

  // Consulta endereços no google com base no endereço informado na tela
  Future<List<Prediction>> buscarEnderecoGooglePlaces(String endereco) async {
    final places = GoogleMapsPlaces(apiKey: DotEnv().env['googleApiKey']);
    var response = await places.autocomplete(endereco, language: 'pt');
    return response.predictions;
  }

  // Consulta os detalhes do endereço que o google retornou
  Future<PlacesDetailsResponse> recuperaDetalhesEnderecosGooglePlaces(
      String placeId) {
    final places = GoogleMapsPlaces(apiKey: DotEnv().env['googleApiKey']);
    return places.getDetailsByPlaceId(placeId);
  }
}
