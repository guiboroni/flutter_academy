import 'package:json_annotation/json_annotation.dart';

part 'access_token_model.g.dart';

@JsonSerializable()
class AccessTokenModel {
  @JsonKey(name: 'access_token')
  String accessToken;

  AccessTokenModel({
    this.accessToken,
  });

  // Recebe um mapa json e retorna uma string
  factory AccessTokenModel.fromJson(Map<String, dynamic> json) =>
      _$AccessTokenModelFromJson(json);

  // Recebe o objeto e retorna ele no formato json, chave:valor
  Map<String, dynamic> toJson() => _$AccessTokenModelToJson(this);
}
