import 'package:cuidapet_curso/app/models/access_token_model.dart';
import 'package:cuidapet_curso/app/repository/facebook_repository.dart';
import 'package:cuidapet_curso/app/repository/security_storage_repository.dart';
import 'package:cuidapet_curso/app/repository/shared_prefs_repository.dart';
import 'package:cuidapet_curso/app/repository/usuario_repository.dart';
import 'package:dio/dio.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';
import 'package:cuidapet_curso/app/core/exceptions/exceptions.dart';

class UsuarioService {
  final UsuarioRepository _repository;

  UsuarioService(this._repository);

  Future<void> login(bool facebookLogin,
      {String email, String password}) async {
    try {
      final prefs = await SharedPrefsRepository.instance;
      final fireAuth = FirebaseAuth.instance;
      AccessTokenModel accessTokenModel;

      // Reliza o login no firebase sem usar o facebook
      if (!facebookLogin) {
        // Pega o token de validação do usuário no backend
        accessTokenModel = await _repository.login(email,
            password: password, facebookLogin: facebookLogin, avatar: '');

        await fireAuth.signInWithEmailAndPassword(
            email: email, password: password);
      }
      // Login pelo facebook
      else {
        var facebookModel = await FacebookRepository().login();
        if (facebookModel != null) {
          accessTokenModel = await _repository.login(facebookModel.email,
              password: password,
              facebookLogin: facebookLogin,
              avatar: facebookModel.picture);
          final facebookCredencial = FacebookAuthProvider.getCredential(
              accessToken: facebookModel.token);
          fireAuth.signInWithCredential(facebookCredencial);
        } else {
          throw AcessoNegadoException('Acesso Negado Facebook');
        }
      }

      // Registra o access token
      prefs.registerAccessToken(accessTokenModel.accessToken);

      final confirmModel = await _repository.confirmLogin();
      prefs.registerAccessToken(confirmModel.accessToken);
      SecurityStorageRepository()
          .registerRefreshToken(confirmModel.refreshToken);
      final dadosUsuario = await _repository.recuperaDadosUsuarioLogado();
      await prefs.registerDadosUsuario(dadosUsuario);
    } on PlatformException catch (e) {
      print('Erro ao fazer login no firebase $e');
      rethrow;
    } on DioError catch (e) {
      if (e.response.statusCode == 403) {
        throw AcessoNegadoException(e.response.data['message'], exception: e);
      } else {
        print(e.response.statusCode);
        rethrow;
      }
    } catch (e) {
      print('Erro ao fazer login $e');
      rethrow;
    }
  }

  Future<void> cadastrarUsuario(String email, String senha) async {
    // ? Cadastra local no backend
    await _repository.cadastrarUsuario(email, senha);

    // ? Cadastra no firebase
    var fireAuth = FirebaseAuth.instance;
    await fireAuth.createUserWithEmailAndPassword(
        email: email, password: senha);
  }
}
