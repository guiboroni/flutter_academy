import 'package:cuidapet_curso/app/models/endereco_model.dart';
import 'package:cuidapet_curso/app/repository/endereco_repository.dart';
import 'package:google_maps_webservice/places.dart';

class EnderecoServices {
  final EnderecoRepository _repository;

  EnderecoServices(this._repository);

  Future<bool> existeEnderecoCadastrado() async {
    var listaEnderecos = await _repository.buscarEnderecos();
    return listaEnderecos.isNotEmpty;
  }

  Future<List<Prediction>> buscarEnderecosGooglePlaces(String endereco) async {
    return await _repository.buscarEnderecoGooglePlaces(endereco);
  }

  Future<void> salvarEndereco(EnderecoModel model) async {
    await _repository.salvarEndereco(model);
  }

  Future<List<EnderecoModel>> buscarEnderecosCadastrados() async {
    return _repository.buscarEnderecos();
  }

  Future<PlacesDetailsResponse> buscarDetalhesEnderecosGooglePlaces(
      String placeId) {
    return _repository.recuperaDetalhesEnderecosGooglePlaces(placeId);
  }
}
