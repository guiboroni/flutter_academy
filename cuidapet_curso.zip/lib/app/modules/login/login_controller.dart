import 'package:cuidapet_curso/app/shared/auth_store.dart';
import 'package:cuidapet_curso/app/shared/components/loader.dart';
import 'package:flutter/cupertino.dart';
import 'package:mobx/mobx.dart';
import 'package:flutter_modular/flutter_modular.dart';
import 'package:cuidapet_curso/app/services/usuario_services.dart';
import 'package:get/get.dart';
import 'package:cuidapet_curso/app/core/exceptions/exceptions.dart';

part 'login_controller.g.dart';

@Injectable()
class LoginController = _LoginControllerBase with _$LoginController;

abstract class _LoginControllerBase with Store {
  final UsuarioService _service;
  GlobalKey<FormState> formKey = GlobalKey();
  TextEditingController loginController = TextEditingController();
  TextEditingController senhaController = TextEditingController();

  @observable
  bool obscureText = true;

  @observable
  int value = 0;

  _LoginControllerBase(this._service);

  @action
  void increment() {
    value++;
  }

  @action
  Future<void> login() async {
    if (formKey.currentState.validate()) {
      try {
        Loader.show();
        await _service.login(false,
            email: loginController.text, password: senhaController.text);
        Loader.hide();
        Modular.to.pushReplacementNamed('/home');
      } on AcessoNegadoException catch (e) {
        Loader.hide();
        print(e);
        Get.snackbar('Erro', 'Login e senha inválidos.');
      } catch (e) {
        Loader.hide();
        print('Erro no login: $e');
        Get.snackbar('Erro', 'Erro ao realizar login');
      }
    }
  }

  @action
  void mostrarSenhaUsuario() {
    obscureText = !obscureText;
  }

  Future<void> facebookLogin() async {
    try {
      Loader.show();
      await _service.login(true);
      await Modular.get<AuthStore>().loadUsuario();
      Loader.hide();
      Modular.to.pushReplacementNamed('/home');
    } on AcessoNegadoException catch (e) {
      Loader.hide();
      print(e);
      Get.snackbar('Erro', 'Login e senha inválidos.');
    } catch (e) {
      Loader.hide();
      print('Erro no login do facebook: $e');
      Get.snackbar('Erro', 'Erro ao realizar login');
    }
  }
}
