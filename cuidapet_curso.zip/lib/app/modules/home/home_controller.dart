import 'package:cuidapet_curso/app/models/endereco_model.dart';
import 'package:cuidapet_curso/app/repository/shared_prefs_repository.dart';
import 'package:cuidapet_curso/app/services/endereco_service.dart';
import 'package:mobx/mobx.dart';
import 'package:flutter_modular/flutter_modular.dart';

part 'home_controller.g.dart';

@Injectable()
class HomeController = _HomeControllerBase with _$HomeController;

abstract class _HomeControllerBase with Store {
  final EnderecoServices _enderecoServices;

  @observable
  EnderecoModel enderecoSelecionado;

  _HomeControllerBase(this._enderecoServices);

  @action
  Future<void> initPage() async {
    await temEnderecoCadastrado();
    await recuperarEnderecoSelecionado();
  }

  Future<void> temEnderecoCadastrado() async {
    var temEndereco = await _enderecoServices.existeEnderecoCadastrado();

    if (!temEndereco) {
      await Modular.link.pushNamed('/enderecos');
    }
  }

  Future<void> recuperarEnderecoSelecionado() async {
    var prefs = await SharedPrefsRepository.instance;
    enderecoSelecionado = await prefs.enderecoSelecionado;
  }
}
