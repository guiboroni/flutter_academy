import 'package:cuidapet_curso/app/models/endereco_model.dart';
import 'package:cuidapet_curso/app/repository/shared_prefs_repository.dart';
import 'package:cuidapet_curso/app/services/endereco_service.dart';
import 'package:cuidapet_curso/app/shared/components/loader.dart';
import 'package:flutter/material.dart';
import 'package:flutter_modular/flutter_modular.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:mobx/mobx.dart';

part 'enderecos_controller.g.dart';

class EnderecosController = _EnderecosControllerBase with _$EnderecosController;

abstract class _EnderecosControllerBase with Store {
  final EnderecoServices _enderecoServices;
  TextEditingController enderecoTextControler = TextEditingController();
  FocusNode enderecoFocusNode = FocusNode();

  @observable
  ObservableFuture<List<EnderecoModel>> enderecosFuture;

  _EnderecosControllerBase(this._enderecoServices);

  Future<List<Prediction>> buscarEnderecos(String endereco) {
    return _enderecoServices.buscarEnderecosGooglePlaces(endereco);
  }

  // Recebe o endereço localizado na página de endereços e repassa com os detalhes para a página de detalhes
  @action
  Future<void> enviarDetalhe(Prediction pred) async {
    var resultado = await _enderecoServices
        .buscarDetalhesEnderecosGooglePlaces(pred.placeId);
    var detalhe = resultado.result;
    var enderecoModel = EnderecoModel(
        id: null,
        endereco: detalhe.formattedAddress,
        latitude: detalhe.geometry.location.lat,
        longitude: detalhe.geometry.location.lng,
        complemento: null);
    var enderecoEdicao =
        await Modular.link.pushNamed('/detalhe', arguments: enderecoModel);
    verificaEdicaoEndereco(enderecoEdicao);
  }

  @action
  void verificaEdicaoEndereco(EnderecoModel enderecoEdicao) {
    // Se o usuário editou o endereço, volta para a tela de endereços, senão recarrega os dados pois ele salvou
    if (enderecoEdicao == null) {
      buscarEnderecosCadastrados();
      enderecoTextControler.text = '';
    } else {
      enderecoTextControler.text = enderecoEdicao.endereco;
      enderecoFocusNode.requestFocus();
    }
  }

  @action
  Future<void> minhaLocalizacao() async {
    Loader.show();
    var geoLocator = Geolocator();
    var position = await geoLocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    var placeMark = await geoLocator.placemarkFromPosition(position);
    var place = placeMark[0];
    var endereco = '${place.thoroughfare} ${place.subThoroughfare}';
    var enderecoModel = EnderecoModel(
        id: null,
        endereco: endereco,
        latitude: position.latitude,
        longitude: position.longitude,
        complemento: null);
    Loader.hide();
    var enderecoEdicao =
        await Modular.link.pushNamed('/detalhe', arguments: enderecoModel);
    verificaEdicaoEndereco(enderecoEdicao);
  }

  @action
  void buscarEnderecosCadastrados() {
    enderecosFuture =
        ObservableFuture(_enderecoServices.buscarEnderecosCadastrados());
  }

  @action
  Future<void> selecionarEndereco(EnderecoModel model) async {
    var prefs = await SharedPrefsRepository.instance;
    await prefs.registrarEnderecoSelecionado(model);
    Modular.to.pop();
  }

  @action
  Future<bool> enderecoFoiSelecionado() async {
    var prefs = await SharedPrefsRepository.instance;
    return await prefs.enderecoSelecionado != null;
  }
}
