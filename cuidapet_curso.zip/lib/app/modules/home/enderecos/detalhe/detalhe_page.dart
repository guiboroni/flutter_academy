import 'dart:io';
import 'package:cuidapet_curso/app/models/endereco_model.dart';
import 'package:cuidapet_curso/app/modules/home/enderecos/detalhe/detalhe_controller.dart';
import 'package:cuidapet_curso/app/shared/theme_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_modular/flutter_modular.dart';
import 'package:flutter_screenutil/screenutil.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class DetalhePage extends StatefulWidget {
  final EnderecoModel enderecoModel;

  const DetalhePage({Key key, @required this.enderecoModel}) : super(key: key);

  @override
  _DetalhePageState createState() => _DetalhePageState(enderecoModel);
}

class _DetalhePageState extends ModularState<DetalhePage, DetalheController> {
  final EnderecoModel model;

  var appBar = AppBar(
    backgroundColor: Colors.white,
    leading: IconButton(
      icon: Icon(Icons.arrow_back, color: ThemeUtils.primaryColor),
      onPressed: () => Modular.to.pop(),
    ),
    elevation: 0,
  );

  _DetalhePageState(this.model);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBar,
      body: SingleChildScrollView(
        child: Container(
          height: _recuperarTamanhoTela(),
          width: ScreenUtil.screenWidthDp,
          padding: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              Text(
                'Confirme seu endereço',
                style: TextStyle(
                  fontSize: 70,
                  color: ThemeUtils.primaryColor,
                  fontWeight: FontWeight.bold,
                ),
                textScaleFactor: ScreenUtil().scaleText,
              ),
              SizedBox(
                height: 20,
              ),
              // Mapa
              Expanded(
                child: GoogleMap(
                  initialCameraPosition: CameraPosition(
                    target: LatLng(model.latitude, model.longitude),
                    zoom: 16,
                  ),
                  markers: {
                    Marker(
                      markerId: MarkerId('end'),
                      position: LatLng(model.latitude, model.longitude),
                      infoWindow: InfoWindow(title: model.endereco),
                    ),
                  },
                  myLocationButtonEnabled: false,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              TextFormField(
                initialValue: model.endereco,
                readOnly: true,
                decoration: InputDecoration(
                  labelText: 'Endereço',
                  suffixIcon: IconButton(
                      icon: Icon(Icons.edit),
                      onPressed: () => Modular.to.pop(model)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              TextFormField(
                controller: controller.complementoTextoController,
                decoration: InputDecoration(labelText: 'Complemento'),
              ),
              SizedBox(
                height: 20,
              ),
              Container(
                width: ScreenUtil.screenWidthDp * .9,
                height: 50,
                child: ElevatedButton(
                  child: Text(
                    'Salvar',
                    style: TextStyle(fontSize: 20),
                  ),
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                        ThemeUtils.primaryColor),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                          side: BorderSide.none),
                    ),
                  ),
                  onPressed: () => controller.salvarEndereco(model),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Utilizado apenas no IOs
  double _recuperarTamanhoTela() {
    var bottomBar = 0.0;
    if (Platform.isIOS) {
      bottomBar = ScreenUtil.bottomBarHeight;
    }
    return ScreenUtil.screenHeightDp -
        (ScreenUtil.statusBarHeight + appBar.preferredSize.height + bottomBar);
  }
}
