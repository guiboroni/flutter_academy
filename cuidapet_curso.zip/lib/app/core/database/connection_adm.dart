import 'package:cuidapet_curso/app/core/database/connection.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_modular/flutter_modular.dart';

class ConnectionADM extends WidgetsBindingObserver with Disposable {
  var conn = Connection();

  ConnectionADM() {
    // Fica verificando os status do app para controlar o db
    WidgetsBinding.instance.addObserver(this);
  }

  // Controla o ciclo de vida do app
  void didChangeAppLifecyleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.resumed:
        break;
      case AppLifecycleState.inactive:
        conn.closeConnection();
        break;
      case AppLifecycleState.paused:
        conn.closeConnection();
        break;
      case AppLifecycleState.detached:
        conn.closeConnection();
        break;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
  }
}
