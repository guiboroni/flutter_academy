import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:cuidapet_curso/app/app_module.dart';

void main() {
  initModule(AppModule());
  // MainPageController mainpage;
  //
  setUp(() {
    //     mainpage = AppModule.to.get<MainPageController>();
  });

  group('MainPageController Test', () {
    //   test("First Test", () {
    //     expect(mainpage, isInstanceOf<MainPageController>());
    //   });

    //   test("Set Value", () {
    //     expect(mainpage.value, equals(0));
    //     mainpage.increment();
    //     expect(mainpage.value, equals(1));
    //   });
  });
}
