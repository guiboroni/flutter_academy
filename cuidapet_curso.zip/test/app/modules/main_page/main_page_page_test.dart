import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('MainPagePage has title', (tester) async {
    //  await tester.pumpWidget(buildTestableWidget(MainPagePage(title: 'MainPage')));
    //  final titleFinder = find.text('MainPage');
    //  expect(titleFinder, findsOneWidget);
  });
}
