import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('HomePage has title', (tester) async {
    //  await tester.pumpWidget(buildTestableWidget(HomePage(title: 'Home')));
    //  final titleFinder = find.text('Home');
    //  expect(titleFinder, findsOneWidget);
  });
}
