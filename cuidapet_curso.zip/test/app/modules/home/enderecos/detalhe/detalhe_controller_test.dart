import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:cuidapet_curso/app/modules/home/enderecos/detalhe/detalhe_controller.dart';
import 'package:cuidapet_curso/app/modules/home/enderecos/enderecos_module.dart';

void main() {
  initModule(EnderecosModule());
  // DetalheController detalhe;
  //
  setUp(() {
    //     detalhe = EnderecosModule.to.get<DetalheController>();
  });

  group('DetalheController Test', () {
    //   test("First Test", () {
    //     expect(detalhe, isInstanceOf<DetalheController>());
    //   });

    //   test("Set Value", () {
    //     expect(detalhe.value, equals(0));
    //     detalhe.increment();
    //     expect(detalhe.value, equals(1));
    //   });
  });
}
