import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_modular/flutter_modular_test.dart';

import 'package:cuidapet_curso/app/modules/home/enderecos/detalhe/detalhe_page.dart';

main() {
  testWidgets('DetalhePage has title', (WidgetTester tester) async {
    //  await tester.pumpWidget(buildTestableWidget(DetalhePage(title: 'Detalhe')));
    //  final titleFinder = find.text('Detalhe');
    //  expect(titleFinder, findsOneWidget);
  });
}
