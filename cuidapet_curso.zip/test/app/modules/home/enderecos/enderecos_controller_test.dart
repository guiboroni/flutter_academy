import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:cuidapet_curso/app/modules/home/enderecos/enderecos_controller.dart';
import 'package:cuidapet_curso/app/modules/home/enderecos/enderecos_module.dart';

void main() {
  initModule(EnderecosModule());
  // EnderecosController enderecos;
  //
  setUp(() {
    //     enderecos = EnderecosModule.to.get<EnderecosController>();
  });

  group('EnderecosController Test', () {
    //   test("First Test", () {
    //     expect(enderecos, isInstanceOf<EnderecosController>());
    //   });

    //   test("Set Value", () {
    //     expect(enderecos.value, equals(0));
    //     enderecos.increment();
    //     expect(enderecos.value, equals(1));
    //   });
  });
}
