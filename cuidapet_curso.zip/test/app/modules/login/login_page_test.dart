import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('LoginPage has title', (tester) async {
    //  await tester.pumpWidget(buildTestableWidget(LoginPage(title: 'Login')));
    //  final titleFinder = find.text('Login');
    //  expect(titleFinder, findsOneWidget);
  });
}
