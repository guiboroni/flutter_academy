import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:cuidapet_curso/app/modules/login/cadastro/cadastro_module.dart';

void main() {
  initModule(CadastroModule());
  // CadastroController cadastro;
  //
  setUp(() {
    //     cadastro = CadastroModule.to.get<CadastroController>();
  });

  group('CadastroController Test', () {
    //   test("First Test", () {
    //     expect(cadastro, isInstanceOf<CadastroController>());
    //   });

    //   test("Set Value", () {
    //     expect(cadastro.value, equals(0));
    //     cadastro.increment();
    //     expect(cadastro.value, equals(1));
    //   });
  });
}
