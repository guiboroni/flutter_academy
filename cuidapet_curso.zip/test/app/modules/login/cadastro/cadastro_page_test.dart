import 'package:flutter_test/flutter_test.dart';

main() {
  testWidgets('CadastroPage has title', (WidgetTester tester) async {
    //  await tester.pumpWidget(buildTestableWidget(CadastroPage(title: 'Cadastro')));
    //  final titleFinder = find.text('Cadastro');
    //  expect(titleFinder, findsOneWidget);
  });
}
