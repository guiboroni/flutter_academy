package br.com.guiboroni.cuidapet_curso

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
