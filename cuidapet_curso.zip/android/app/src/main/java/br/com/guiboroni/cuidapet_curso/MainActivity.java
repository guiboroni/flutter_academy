package br.com.guiboroni.cuidapet_curso;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
