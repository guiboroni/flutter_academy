import 'package:desafio_09/app/pages/produto_page.dart';
import 'package:flutter/material.dart';
import 'pages/home_page.dart';

class MainPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomePage(),
    );
  }
}
