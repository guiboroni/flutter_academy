import 'package:flutter/material.dart';

class ProdutoPage extends StatefulWidget {
  static String routerName = '/produto';

  final String tipo;
  final String nome;
  final String cor;
  final double nota;
  final String tempoMedio;
  final double preco;

  ProdutoPage(
      {this.nome, this.cor, this.nota, this.tempoMedio, this.tipo, this.preco});

  @override
  _ProdutoPageState createState() =>
      _ProdutoPageState(tipo, nome, cor, nota, tempoMedio, preco);
}

class _ProdutoPageState extends State<ProdutoPage> {
  final String tipo;
  final String nome;
  final String cor;
  final double nota;
  final String tempoMedio;
  final double preco;

  _ProdutoPageState(
      this.tipo, this.nome, this.cor, this.nota, this.tempoMedio, this.preco);

  double totalProduto;
  int qtdeProduto = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Selecionar Produtos'),
        actions: [
          Icon(Icons.help),
        ],
      ),
      body: Container(
        color: Color.fromARGB(255, 238, 238, 238),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 100,
              color: Colors.white,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          children: [
                            Container(
                              height: 30,
                              width: 30,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: Colors.grey[300],
                                borderRadius: BorderRadius.circular(50),
                              ),
                              child: Container(
                                height: 15,
                                width: 15,
                                decoration: BoxDecoration(
                                  color: Colors.blue,
                                  borderRadius: BorderRadius.circular(50),
                                ),
                              ),
                            ),
                            Text('Comprar'),
                          ],
                        ),
                        Container(
                          width: 40,
                          child: Divider(
                            color: Colors.grey,
                            height: 20,
                          ),
                        ),
                        Column(
                          children: [
                            Icon(Icons.brightness_1_outlined),
                            Text('Pagamento'),
                          ],
                        ),
                        Container(
                          width: 40,
                          child: Divider(
                            color: Colors.grey,
                            height: 20,
                          ),
                        ),
                        Column(
                          children: [
                            Icon(Icons.brightness_1_outlined),
                            Text('Confirmação'),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Divider(
                    color: Color.fromARGB(255, 238, 238, 238),
                    height: 1,
                    thickness: 2,
                  ),
                  Container(
                    height: 50,
                    color: Colors.white,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          margin: EdgeInsets.only(
                            left: 20,
                          ),
                          child: Row(
                            children: [
                              Container(
                                height: 25,
                                width: 25,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  color: Colors.black,
                                  borderRadius: BorderRadius.circular(30),
                                ),
                                child: Text(
                                  '1',
                                  style: TextStyle(
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(
                                  left: 5,
                                ),
                                child: Text(
                                  '$nome - Botijão de 13kg',
                                  style: TextStyle(
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(
                            right: 20,
                          ),
                          child: Row(
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.only(top: 10, right: 2),
                                child: Text(
                                  'R\$',
                                  style: TextStyle(
                                    fontSize: 8,
                                  ),
                                ),
                              ),
                              Text(
                                totalProduto == null
                                    ? preco.toStringAsFixed(2)
                                    : totalProduto.toStringAsFixed(2),
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: 160,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(
                                left: 10, top: 15, bottom: 15, right: 2),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(
                                  Icons.home,
                                  color: Colors.grey,
                                  size: 40,
                                ),
                                Column(
                                  children: [
                                    Text(
                                      nome,
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Row(
                                      children: [
                                        Text(nota.toString()),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(left: 3),
                                          child: Icon(
                                            Icons.star,
                                            color: Colors.orange,
                                            size: 10,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                    top: 21,
                                  ),
                                  child: Text(
                                    '$tempoMedio min',
                                  ),
                                ),
                                Container(
                                  color: Color(int.parse(cor)),
                                  padding: EdgeInsets.all(4),
                                  child: Text(
                                    tipo,
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 10,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Divider(
                            color: Color.fromARGB(255, 238, 238, 238),
                            height: 1,
                            thickness: 2,
                          ),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                  top: 15,
                                  left: 50,
                                ),
                                child: Column(
                                  children: [
                                    Text('Botijão de 13kg'),
                                    SizedBox(
                                      height: 3,
                                    ),
                                    Text(nome),
                                    SizedBox(
                                      height: 3,
                                    ),
                                    Row(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(
                                            top: 8,
                                            right: 3,
                                          ),
                                          child: Text(
                                            'R\$',
                                            style: TextStyle(
                                              fontSize: 10,
                                            ),
                                          ),
                                        ),
                                        Text(
                                          preco.toStringAsFixed(2),
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(
                                      right: 5,
                                      top: 10,
                                    ),
                                    child: InkWell(
                                        onTap: () {
                                          setState(() {
                                            qtdeProduto--;

                                            qtdeProduto = qtdeProduto < 0
                                                ? 0
                                                : qtdeProduto;

                                            totalProduto = qtdeProduto == 0
                                                ? 0
                                                : qtdeProduto * preco;
                                          });
                                        },
                                        child: Icon(
                                          Icons.remove_circle,
                                          size: 35,
                                          color: Colors.grey,
                                        )),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                      right: 5,
                                      top: 10,
                                    ),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Center(
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Image(
                                              image: AssetImage(
                                                'assets/images/icon_gas.png',
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.only(top: 7),
                                              padding: EdgeInsets.all(2),
                                              decoration: BoxDecoration(
                                                color: Colors.orange,
                                                borderRadius:
                                                    BorderRadius.circular(5),
                                              ),
                                              child:
                                                  Text(qtdeProduto.toString()),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                      top: 10,
                                      right: 5,
                                    ),
                                    child: InkWell(
                                        onTap: () {
                                          setState(() {
                                            qtdeProduto++;

                                            totalProduto = qtdeProduto * preco;
                                          });
                                        },
                                        child: Icon(
                                          Icons.add_circle,
                                          size: 35,
                                          color: Colors.grey,
                                        )),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: 210,
                      height: 70,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                            colors: [Colors.blue[300], Colors.blue[700]]),
                        borderRadius: BorderRadius.circular(50),
                      ),
                      child: InkWell(
                        onTap: () => print('Clicou no botão'),
                        child: Center(
                          child: Text(
                            'IR PARA O PAGAMENTO',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
