import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'revenda_page.dart';

class HomePage extends StatefulWidget {
  static String routerName = '/';

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<dynamic> revendas;

  @override
  void initState() {
    super.initState();
    rootBundle.loadString('assets/dados.json').then((value) {
      setState(() {
        revendas = json.decode(value);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Escolha uma Revenda'),
        actions: [
          PopupMenuButton(
            icon: Icon(Icons.import_export),
            itemBuilder: (ctx) => <PopupMenuEntry<Null>>[
              new PopupMenuItem(
                child: new CheckboxListTile(
                  value: false,
                  selected: false,
                  title: Text('Melhor Avaliação'),
                  controlAffinity: ListTileControlAffinity.trailing,
                  onChanged: (bool value) {},
                ),
                value: null,
              ),
              new PopupMenuItem(
                child: new CheckboxListTile(
                  value: false,
                  selected: false,
                  title: Text('Mais Rápido'),
                  controlAffinity: ListTileControlAffinity.trailing,
                  onChanged: (bool value) {},
                ),
                value: null,
              ),
              new PopupMenuItem(
                child: new CheckboxListTile(
                  value: false,
                  selected: false,
                  title: Text('Mais Barato'),
                  controlAffinity: ListTileControlAffinity.trailing,
                  onChanged: (bool value) {},
                ),
                value: null,
              ),
            ],
          ),
          PopupMenuButton(
            icon: Icon(Icons.help),
            itemBuilder: (BuildContext context) {
              return [
                PopupMenuItem(
                  value: 1,
                  child: Text('Suporte'),
                ),
                PopupMenuItem(
                  value: 2,
                  child: Text('Termos de Serviço'),
                ),
              ];
            },
          ),
        ],
      ),
      body: Container(
        color: Color.fromARGB(255, 238, 238, 238),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              color: Colors.white,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: EdgeInsets.all(15),
                    color: Colors.white,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Botijões de 13kg em:',
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.grey,
                          ),
                        ),
                        Text('Av Paulista, 1001'),
                        Text(
                          'Paulista, São Paulo, SP',
                          style: TextStyle(
                            fontSize: 15,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    color: Colors.white,
                    padding: EdgeInsets.all(15),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.location_on,
                          color: Colors.blue,
                        ),
                        Text(
                          'Mudar',
                          style: TextStyle(color: Colors.blue),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                child: ListView.builder(
                  itemCount: revendas?.length ?? 0,
                  itemBuilder: (context, index) {
                    return RevendaPage(
                      revendas[index]['tipo'],
                      revendas[index]['nome'],
                      revendas[index]['cor'],
                      revendas[index]['nota'],
                      revendas[index]['tempoMedio'],
                      revendas[index]['melhorPreco'],
                      revendas[index]['preco'],
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
