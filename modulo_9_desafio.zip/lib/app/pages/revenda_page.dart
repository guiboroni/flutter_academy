import 'package:desafio_09/app/pages/produto_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'produto_page.dart';

class RevendaPage extends StatefulWidget {
  static String routerName = '/revendas';

  final String tipo;
  final String nome;
  final String cor;
  final double nota;
  final String tempoMedio;
  final bool melhorPreco;
  final double preco;

  RevendaPage(this.tipo, this.nome, this.cor, this.nota, this.tempoMedio,
      this.melhorPreco, this.preco);

  @override
  _RevendaPageState createState() => _RevendaPageState(
      tipo, nome, '0xFF' + cor, nota, tempoMedio, melhorPreco, preco);
}

class _RevendaPageState extends State<RevendaPage> {
  final String tipo;
  final String nome;
  final String cor;
  final double nota;
  final String tempoMedio;
  final bool melhorPreco;
  final double preco;

  _RevendaPageState(this.tipo, this.nome, this.cor, this.nota, this.tempoMedio,
      this.melhorPreco, this.preco);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ProdutoPage(
                tipo: tipo,
                nome: nome,
                cor: cor,
                nota: nota,
                tempoMedio: tempoMedio,
                preco: preco,
              ),
            ));
      },
      child: Container(
        padding: EdgeInsets.only(top: 20, left: 20, bottom: 5),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  width: 35,
                  height: 120,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(5),
                      topLeft: Radius.circular(5),
                    ),
                    color: Color(int.parse(cor)),
                  ),
                  child: RotatedBox(
                    quarterTurns: -1,
                    child: Center(
                      child: Text(
                        tipo,
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                  width: ScreenUtil().screenWidth -
                      75, // não entendi o motivo desse valor ???
                  height: 120,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(5),
                      bottomRight: Radius.circular(5),
                    ),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(
                              left: 10.0,
                              top: 25,
                              bottom: 25,
                            ),
                            child: Text(
                              nome,
                            ),
                          ),
                          Visibility(
                            visible: melhorPreco,
                            child: Padding(
                              padding: const EdgeInsets.only(
                                left: 10.0,
                                top: 15,
                                bottom: 20,
                              ),
                              child: Container(
                                padding: EdgeInsets.only(
                                  left: 5,
                                  top: 4,
                                  right: 5,
                                  bottom: 4,
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.only(
                                    bottomLeft: Radius.circular(5),
                                    topLeft: Radius.circular(5),
                                  ),
                                  color: Colors.orange,
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.label,
                                      color: Colors.white,
                                    ),
                                    Text(
                                      'Melhor Preço',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 10,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 20, right: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              height: 50,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Nota',
                                    style: TextStyle(
                                      color: Colors.grey,
                                      fontSize: 11,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Row(
                                    children: [
                                      Text(
                                        nota.toStringAsFixed(2),
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20),
                                      ),
                                      Icon(
                                        Icons.star,
                                        color: Colors.yellow,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              height: 50,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    'Tempo Médio',
                                    style: TextStyle(
                                      color: Colors.grey,
                                      fontSize: 11,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Row(
                                    children: [
                                      Text(
                                        tempoMedio,
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(top: 7.0),
                                        child: Text(
                                          'min',
                                          style: TextStyle(
                                            color: Colors.grey,
                                            fontSize: 11,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              height: 50,
                              child: Column(
                                children: [
                                  Text(
                                    'Preço',
                                    style: TextStyle(
                                      color: Colors.grey,
                                      fontSize: 11,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Row(
                                    children: [
                                      Text(
                                        'R\$ ' + preco.toStringAsFixed(2),
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
