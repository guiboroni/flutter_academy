import 'package:flutter/material.dart';
import 'app/main_page.dart';

void main() {
  runApp(MainPage());
}
