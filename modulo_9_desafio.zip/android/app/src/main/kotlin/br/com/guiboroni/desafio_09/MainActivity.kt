package br.com.guiboroni.desafio_09

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
