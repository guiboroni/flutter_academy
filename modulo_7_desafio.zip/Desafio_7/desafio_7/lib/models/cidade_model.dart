import 'dart:convert';

class CidadeModel {
  int id;
  String nome;

  CidadeModel({this.id, this.nome});

  Map<String, dynamic> toMap() {
    return {'id': id, 'nome': nome};
  }

  factory CidadeModel.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return CidadeModel(id: map['id'], nome: map['nome']);
  }

  String toJson() => json.encode(toMap());

  factory CidadeModel.fromJson(String source) =>
      CidadeModel.fromMap(json.decode(source));
}
