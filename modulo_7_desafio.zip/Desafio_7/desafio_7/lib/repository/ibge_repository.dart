import 'package:desafio_7/models/cidade_model.dart';
import 'package:desafio_7/models/estado_model.dart';
import 'package:desafio_7/models/regiao_model.dart';
import 'package:dio/dio.dart';

class IBGERepository {
  Future<List<dynamic>> buscarRegioes() async {
    var url = 'https://servicodados.ibge.gov.br/api/v1/localidades/regioes';

    var dio = Dio();
    var response = await dio.get(url);

    if (response.statusCode == 200) {
      var respData = response.data;
      var regioes = respData.map((e) => RegiaoModel.fromMap(e)).toList();
      return regioes;
    }
  }

  Future<List<dynamic>> buscarEstados(int idRegiao) async {
    var url =
        'https://servicodados.ibge.gov.br/api/v1/localidades/regioes/${idRegiao}/estados';

    var dio = Dio();
    var response = await dio.get(url);

    if (response.statusCode == 200) {
      var respData = response.data;
      var estados = respData.map((e) => EstadoModel.fromMap(e)).toList();
      return estados;
    }
  }

  Future<List<dynamic>> buscarCidades(int idEstado) async {
    var url =
        'https://servicodados.ibge.gov.br/api/v1/localidades/estados/${idEstado}/municipios';

    var dio = Dio();
    var response = await dio.get(url);

    if (response.statusCode == 200) {
      var respData = response.data;
      var cidades = respData.map((e) => CidadeModel.fromMap(e)).toList();
      return cidades;
    }
  }
}
