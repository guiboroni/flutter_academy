import 'package:mysql1/mysql1.dart';

Future<MySqlConnection> getConnection() async {
  var settings = ConnectionSettings(
      host: 'localhost',
      port: 3306,
      user: 'root',
      password: 'root',
      db: 'desafio_7');
  return await MySqlConnection.connect(settings);
}

Future<void> cadastrarRegiao(
    String nomeRegiao, String siglaRegiao, int idRegiao) async {
  var conn = await getConnection();
  try {
    await conn.query(
        'insert regiao (cd_regiao, nome, sigla, id_regiao) values (null, ?, ?, ?)',
        [nomeRegiao, siglaRegiao, idRegiao]);
  } catch (e) {
    print(e);
  } finally {
    await conn.close();
  }
}

Future<void> cadastrarEstado(
    String nomeEstado, String siglaEstado, int idEstado, int idRegiao) async {
  var conn = await getConnection();
  try {
    await conn.query(
        'insert estado (cd_estado, nome, sigla, id_regiao, id_estado) values (null, ?, ?, ?, ?)',
        [nomeEstado, siglaEstado, idRegiao, idEstado]);
  } catch (e) {
    print(e);
  } finally {
    await conn.close();
  }
}

Future<void> cadastrarCidades(List<dynamic> cidades, int idEstado) async {
  var conn = await getConnection();
  try {
    await Future.forEach(cidades, (cidade) async {
      await conn.query(
          'insert cidade (cd_cidade, nome, id_estado) values (null, ?, ?)',
          [cidade.nome, idEstado]);
    });
  } catch (e) {
    print(e);
  } finally {
    await conn.close();
  }
}
