import 'package:desafio_7/repository/ibge_repository.dart';
import 'package:desafio_7/mysql.dart' as mysql;

Future<void> run() async {
  await cadastroGeral();
}

Future<void> cadastroGeral() async {
  var regioes = await IBGERepository().buscarRegioes();

  await Future.forEach(regioes, (regiao) async {
    await mysql.cadastrarRegiao(regiao.nome, regiao.sigla, regiao.id);

    var estadosRegiao = await IBGERepository().buscarEstados(regiao.id);
    await Future.forEach(estadosRegiao, (estado) async {
      await mysql.cadastrarEstado(
          estado.nome, estado.sigla, regiao.id, estado.id);

      var cidadesEstado = await IBGERepository().buscarCidades(estado.id);
      await mysql.cadastrarCidades(cidadesEstado, estado.id);
    });
  });
}
